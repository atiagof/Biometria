﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SistemaBiometria.MODEL
{
    public class Sistema
    {
        public int Id_Sistema { get; set; }
        public string Descricao { get; set; }
        public string CheckBoxSelect { get; set; }
    }
}